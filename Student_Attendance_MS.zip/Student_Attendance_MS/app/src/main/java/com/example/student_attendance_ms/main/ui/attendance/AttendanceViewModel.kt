package com.example.student_attendance_ms.main.ui.attendance

import androidx.lifecycle.ViewModel

class AttendanceViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
