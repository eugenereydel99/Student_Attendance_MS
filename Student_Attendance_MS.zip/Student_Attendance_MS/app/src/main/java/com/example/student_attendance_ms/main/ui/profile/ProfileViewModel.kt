package com.example.student_attendance_ms.main.ui.profile

import androidx.lifecycle.ViewModel

class ProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
